import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:usb_serial/usb_serial.dart';
import 'package:usb_serial/transaction.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Debugاخفاء علامه  
      title: 'USB Serial + Robot Arm',
      theme: ThemeData(
        colorSchemeSeed: const Color.fromARGB(255, 23, 150, 196),
        useMaterial3: true,
      ),
      home: const SerialAndRobotPage(), // الصفحه الرئيسيه
    );
  }
}

class SerialAndRobotPage extends StatefulWidget {
  const SerialAndRobotPage({super.key});
  @override
  State<SerialAndRobotPage> createState() => _SerialAndRobotPageState();
}

class _SerialAndRobotPageState extends State<SerialAndRobotPage> {

  List<UsbDevice> _devices = [];           
  StreamSubscription<UsbEvent>? _usbSub;     
  UsbPort? _port;                          
  Transaction<String>? _transaction;        
  StreamSubscription<String>? _rxSub;     

  bool _isOpen = false;                    
  final int _baud = 115200;               

  final _serialLog = StringBuffer();           

  void _log(String s) {
    _serialLog.writeln(s);
    setState(() {});
  }

  Future<void> _refreshDevices() async {
    _devices = await UsbSerial.listDevices();
    setState(() {});
  }

  Future<void> _connect(UsbDevice d) async {
    await _disconnect(); 

    final created = await d.create();
    if (created == null) {
      _log('❌ Could not create port for ${d.productName}');
      return;
    }
    _port = created;

    final opened = await _port!.open(); 
    if (!opened) {
      _log('❌ Failed to open ${d.productName}');
      _port = null;
      return;
    }

    await _port!.setDTR(true);
    await _port!.setRTS(true);
    await _port!.setPortParameters(
      _baud,
      UsbPort.DATABITS_8,
      UsbPort.STOPBITS_1,
      UsbPort.PARITY_NONE,
    );

    final input = _port!.inputStream;
    if (input == null) {
      _log('⚠️ No input stream from device.');
    } else {
      _transaction = Transaction.stringTerminated(
        input,
        Uint8List.fromList([13, 10]),
      );
      _rxSub = _transaction!.stream.listen((line) {
        _log('RX: $line');
      });
    }

    _isOpen = true;
    _log('✅ Connected to ${d.productName} (BaudRate: $_baud)');
    setState(() {});
  }

  Future<void> _disconnect() async {
    _rxSub?.cancel();
    _rxSub = null;

    _transaction?.dispose();
    _transaction = null;

    if (_port != null) {
      await _port!.close();
      _port = null;
    }
    if (_isOpen) _log('🔌 Disconnected');
    _isOpen = false;
    setState(() {});
  }

  Future<void> _sendLine(String text) async {
    if (_port == null) {
      _log('⚠️ Not connected');
      return;
    }
    final line = '$text\n'; 
    await _port!.write(Uint8List.fromList(line.codeUnits));
    _log('✅ Sent: $text');
  }

  static const int motorCount = 4;                     // عدد المحركات
  final List<int> values = List<int>.filled(motorCount, 90); 

  String _buildCommand() =>
      's1${values[0]},s2${values[1]},s3${values[2]},s4${values[3]}';

  void _resetSliders() {
    for (var i = 0; i < values.length; i++) values[i] = 90;
    setState(() {});
  }

  Future<void> _run() async => _sendLine(_buildCommand());

  @override
  void initState() {
    super.initState();
    _refreshDevices(); 
    _usbSub = UsbSerial.usbEventStream?.listen((event) {
      _refreshDevices();
      final v = event.device?.vid;
      final p = event.device?.pid;
      _log('🔔 USB ${event.event} (vid:${v ?? "?"} pid:${p ?? "?"})');
    });
  }

  @override
  void dispose() {
    _usbSub?.cancel();
    _disconnect(); 
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          'USB Serial Interface  |  Robot Arm Control',
          style: TextStyle(
            decoration: TextDecoration.underline,
            decorationThickness: 2,
          ),
        ),
      ),
      body: Row(
        children: [
          Expanded(
            flex: 1,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: _buildLeftPane(),
            ),
          ),
          const VerticalDivider(width: 1), 
          Expanded(
            flex: 1,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: _buildRightPane(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLeftPane() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('الأجهزة / Devices', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),

        Expanded(
          child: ListView(
            children: _devices.map((d) {
              final title = d.productName ?? 'USB Device';
              final subtitle = 'VID: ${d.vid} / PID: ${d.pid}';
              return Card(
                child: ListTile(
                  title: Text(title),
                  subtitle: Text(subtitle),
                  trailing: ElevatedButton(
                    onPressed: () => _connect(d),
                    child: const Text('اتصال / Connect'),
                  ),
                ),
              );
            }).toList(),
          ),
        ),

        const SizedBox(height: 12),
        Center(
          child: OutlinedButton(
            onPressed: _refreshDevices,
            child: const Text('اختبار/تحديث الاتصال  •  Refresh'),
          ),
        ),

    const SizedBox(height: 16),
    Row(
    children: [
    const Icon(Icons.article_outlined, size: 18),
    const SizedBox(width: 6),
    const Text('Serial Console:', style: TextStyle(fontWeight: FontWeight.bold)),
    const Spacer(),
    IconButton(
    tooltip: 'Clear',
    onPressed: () {
    _serialLog.clear();
    setState(() {});
    },
    icon: const Icon(Icons.cleaning_services_outlined),
    ),
    ],
    ),

    Expanded(
    flex: 0,
    child: Container(
    height: 180,
    padding: const EdgeInsets.all(8),
    decoration: BoxDecoration(
    color: Colors.black.withOpacity(.04),
    borderRadius: BorderRadius.circular(8),
    border: Border.all(color: Colors.black12),
    ),
    alignment: Alignment.topLeft,
    child: SingleChildScrollView(
    reverse: true, 
    child: Text(
    '${_isOpen ? '☑️ Connected\n' : '⛔ Not Connected\n'}${_serialLog.toString()}',
    style: const TextStyle(fontFamily: 'monospace'), 
    ),
    ),
    ),
    ),
  ],
    );
  }

  Widget _buildRightPane() {
    return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
    const Text('Robot Arm Control Panel', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    const Icon(Icons.usb, size: 22),
    const SizedBox(height: 12),
    for (var i = 0; i < values.length; i++) ...[
    Text('Motor ${i + 1}: ${values[i]}'),
    Slider(
    value: values[i].toDouble(),
    min: 0,
    max: 180,
    divisions: 180, 
    label: '${values[i]}',
    onChanged: (v) => setState(() => values[i] = v.round()),
    ),
    const SizedBox(height: 8),
    ],

    Row(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: [
    OutlinedButton(onPressed: _resetSliders, child: const Text('Reset')),
    ElevatedButton(onPressed: _run, child: const Text('Run')),
    ],
    ),

    const SizedBox(height: 16),
    Row(
      children: const [
      Icon(Icons.article_outlined, size: 18),
      SizedBox(width: 6),
      Text('Serial Console:', style: TextStyle(fontWeight: FontWeight.bold)),
      ],
      ),
      const SizedBox(height: 6),
      Container(
      height: 180,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
      color: Colors.black.withOpacity(.04),
      borderRadius: BorderRadius.circular(8),
      border: Border.all(color: Colors.black12),
      ),
      alignment: Alignment.topLeft,
      child: SingleChildScrollView(
      reverse: true,
      child: Text(
      [
      if (_serialLog.isNotEmpty)
      'Last: ${_serialLog.toString().trim().split('\n').last}', 
      'Servo 1: ${values[0]}',
      'Servo 2: ${values[1]}',
      'Servo 3: ${values[2]}',
      'Servo 4: ${values[3]}',
      ].join('\n'),
      style: const TextStyle(fontFamily: 'monospace'),
      ),
      ),
      ),
      ],
    );
  }
}