<?php
// get_run_pose.php  (4 servos)
// Returns:
//   "1,s1<..>,s2<..>,s3<..>,s4<..>"  when a pending run exists
//   "0"                               when nothing is pending
header('Content-Type: text/plain; charset=utf-8');
require 'db.php';

$consume = (isset($_GET['consume']) && $_GET['consume'] == '1');

$sql = "SELECT id, servo1, servo2, servo3, servo4
        FROM run
        WHERE status = 1
        ORDER BY id DESC
        LIMIT 1";
$res = $conn->query($sql);

if ($res && $res->num_rows) {
  $r = $res->fetch_assoc();
  echo "1,s1{$r['servo1']},s2{$r['servo2']},s3{$r['servo3']},s4{$r['servo4']}";
  if ($consume) {
    $stmt = $conn->prepare("UPDATE run SET status = 0 WHERE id = ?");
    $stmt->bind_param("i", $r['id']);
    $stmt->execute();
    $stmt->close();
  }
} else {
  echo "0";
}