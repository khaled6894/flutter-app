<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

require 'db.php';

$vals = [];
for ($i = 1; $i <= 4; $i++) {
  $k = "servo$i";
  $vals[$i] = max(0, min(180, intval($_POST[$k] ?? 90))); // clamp 0..180
}

$stmt = $conn->prepare(
  "INSERT INTO pose (servo1, servo2, servo3, servo4) VALUES (?, ?, ?, ?)"
);
$stmt->bind_param("iiii", $vals[1], $vals[2], $vals[3], $vals[4]);
$ok = $stmt->execute();
$id = $conn->insert_id;
$stmt->close();

echo json_encode(['ok' => (bool)$ok, 'id' => (int)$id]);