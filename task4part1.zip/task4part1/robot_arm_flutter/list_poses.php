<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require 'db.php';

$sql = "SELECT id, servo1, servo2, servo3, servo4
        FROM pose
        WHERE status = 1
        ORDER BY id DESC";
$res = $conn->query($sql);

$out = [];
if ($res) {
  while ($row = $res->fetch_assoc()) $out[] = $row;
}
echo json_encode($out);