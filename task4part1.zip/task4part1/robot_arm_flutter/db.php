<?php
header('Content-Type: application/json');

$host = '127.0.0.1';
$user = 'root';
$pass = '';     
$db   = 'flutter_robot_arm';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_errno) {
  http_response_code(500);
  die(json_encode(['error' => $conn->connect_error]));
}
$conn->set_charset('utf8mb4');