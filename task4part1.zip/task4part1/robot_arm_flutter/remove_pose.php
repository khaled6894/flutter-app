<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

require 'db.php';

$id = intval($_POST['id'] ?? 0);
if ($id <= 0) { echo json_encode(['ok' => false, 'msg' => 'bad id']); exit; }

$stmt = $conn->prepare("UPDATE pose SET status = 0 WHERE id = ?");
$stmt->bind_param("i", $id);
$ok = $stmt->execute();
$stmt->close();

echo json_encode(['ok' => (bool)$ok]);