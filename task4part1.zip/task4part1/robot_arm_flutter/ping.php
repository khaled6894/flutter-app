<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
require 'db.php';
$r = $conn->query("SELECT COUNT(*) AS c FROM pose");
echo json_encode(['ok' => true, 'poses' => ($r ? (int)$r->fetch_assoc()['c'] : 0)]);